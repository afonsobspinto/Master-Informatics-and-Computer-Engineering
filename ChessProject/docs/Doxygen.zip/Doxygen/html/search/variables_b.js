var searchData=
[
  ['name',['name',['../struct_piece.html#afc65b5080badbd1e1482dae3cc685b5b',1,'Piece']]],
  ['ncolors',['nColors',['../struct_bitmap_info_header.html#aed4506bad904845183194f199f1bdb98',1,'BitmapInfoHeader']]],
  ['next_5fpiece',['next_piece',['../struct_mouse.html#a15937e4cb1bf860a9ea8e24e5e41d7e0',1,'Mouse']]],
  ['nine',['nine',['../bitmap_8c.html#a7991e77893cb1df475d8f5486a9fccc9',1,'bitmap.c']]],
  ['numberofbanks',['NumberOfBanks',['../struct____attribute____.html#aa955c03441b6d3e55b2ba4be4dae56a2',1,'__attribute__']]],
  ['numberofimagepages',['NumberOfImagePages',['../struct____attribute____.html#a7033bb4cac6dc49f68ca4df855151e09',1,'__attribute__']]],
  ['numberofplanes',['NumberOfPlanes',['../struct____attribute____.html#a51268efaac55d78e17263aff9a447998',1,'__attribute__']]]
];
