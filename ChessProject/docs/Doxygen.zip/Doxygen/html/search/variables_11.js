var searchData=
[
  ['v_5fres',['v_res',['../video__gr_8c.html#a5bda1b499253a8fbf3cab646f8760391',1,'video_gr.c']]],
  ['vbesignature',['vbeSignature',['../struct____attribute____.html#adc71f23c894158ec39d18a8363fd8d85',1,'__attribute__']]],
  ['vbeversion',['vbeVersion',['../struct____attribute____.html#a925707096b1bd5e7581cf31cc1b4a6bf',1,'__attribute__']]],
  ['video_5fmem',['video_mem',['../video__gr_8c.html#a93a24e067b9083bed6fb5c0336fd7a01',1,'video_gr.c']]],
  ['videomodeptr',['videoModePtr',['../struct____attribute____.html#a3faa9a6cdfee09c279ccedac8e22f6d6',1,'__attribute__']]],
  ['virtual',['virtual',['../group__lmlib.html#ga6a0ea2231d30f2b025e0c4b9f12dd6db',1,'mmap_t']]]
];
