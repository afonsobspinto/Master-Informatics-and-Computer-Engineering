var searchData=
[
  ['pb2base',['PB2BASE',['../vbe_8c.html#a68b87c2339cb305d66b69b5551b96c73',1,'vbe.c']]],
  ['pb2off',['PB2OFF',['../vbe_8c.html#a70c65ed4c6d71865daa96d31befb33fd',1,'vbe.c']]],
  ['pcconfig',['PCCONFIG',['../macros_8h.html#a6db2856526a91795c1d5a1e69cb5a7c5',1,'macros.h']]],
  ['promotion',['PROMOTION',['../chess_8h.html#af85750afa029945a41d41b614de03f8d',1,'chess.h']]]
];
