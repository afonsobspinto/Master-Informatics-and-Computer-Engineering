var searchData=
[
  ['directcolormodeinfo',['DirectColorModeInfo',['../struct____attribute____.html#a3bf2fd2394ec8649ec3d26104be35dd7',1,'__attribute__']]],
  ['draw',['draw',['../bitmap_8c.html#a3c8c67efb68a9e74dad346d584e1f7a9',1,'bitmap.c']]]
];
