var searchData=
[
  ['checkmate',['CHECKMATE',['../chess_8h.html#abec42f1abae3c920d7804783ac4e8eef',1,'chess.h']]],
  ['cols',['COLS',['../utilities_8h.html#ab59ad2ee1a48b83c2eef1f019ed8cc48',1,'utilities.h']]],
  ['correction',['CORRECTION',['../utilities_8h.html#a6b2cea537eda125cb3b39529ca4696f7',1,'utilities.h']]]
];
