var searchData=
[
  ['alignment',['Alignment',['../group___bitmap.html#gacdfaca60ec19c0265bac2692d7982726',1,'bitmap.h']]]
];
