var searchData=
[
  ['third_5fbuffer',['THIRD_BUFFER',['../utilities_8h.html#a63b34c1858d3b0ed84aeba97fc28162a',1,'utilities.h']]],
  ['timex',['TIMEX',['../utilities_8h.html#a32eeb5ea5d3a32039c13b74137dc5bc0',1,'utilities.h']]],
  ['timey',['TIMEY',['../utilities_8h.html#a3662b0eb834e198ab900720e51ee03ad',1,'utilities.h']]],
  ['two_5fbyte_5fscan',['TWO_BYTE_SCAN',['../macros_8h.html#aeaace70a848986aba05d3e74cdc9c19a',1,'macros.h']]]
];
