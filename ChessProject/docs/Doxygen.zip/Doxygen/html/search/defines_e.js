var searchData=
[
  ['v_5fres',['V_RES',['../video__gr_8c.html#aac2466862bcfc18231c38fe1eacc22e3',1,'video_gr.c']]],
  ['vbe_5fax',['VBE_AX',['../macros_8h.html#a566710d88e5032e5fab1572304c15e24',1,'macros.h']]],
  ['vbe_5ffunct',['VBE_FUNCT',['../macros_8h.html#a6c843a9627e595b9461434af3a82e2ba',1,'macros.h']]],
  ['vbe_5finfo',['VBE_INFO',['../macros_8h.html#a3922b6a34fe4aa377b3ed72a6b115e2e',1,'macros.h']]],
  ['vbe_5fmode_5finfo',['VBE_MODE_INFO',['../macros_8h.html#a2ecbf8f92f9322fedec91461747c4843',1,'macros.h']]],
  ['video_5fmem',['VIDEO_MEM',['../utilities_8h.html#a75bd6d80644f73b99985a3046e3f39cb',1,'utilities.h']]],
  ['videocard',['VIDEOCARD',['../macros_8h.html#a025fb3d92475390b59a13c9bef8432fc',1,'macros.h']]],
  ['vram_5fphys_5faddr',['VRAM_PHYS_ADDR',['../video__gr_8c.html#ac854e8352d97c69bdfe247573593ba3b',1,'video_gr.c']]]
];
