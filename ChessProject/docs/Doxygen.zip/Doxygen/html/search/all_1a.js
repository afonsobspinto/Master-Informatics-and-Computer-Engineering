var searchData=
[
  ['zero',['zero',['../bitmap_8c.html#a91347817cce11b30126d7223757eecaa',1,'bitmap.c']]]
];
