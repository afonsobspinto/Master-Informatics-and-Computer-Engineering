var searchData=
[
  ['i',['i',['../struct_piece.html#acb559820d9ca11295b4500f179ef6392',1,'Piece']]],
  ['imagesize',['imageSize',['../struct_bitmap_info_header.html#adcd57a0168319e747bc8099218d3822c',1,'BitmapInfoHeader']]],
  ['importantcolors',['importantColors',['../struct_bitmap_info_header.html#a8f7abfbc446b12f385d2b42c3b4fd9b0',1,'BitmapInfoHeader']]]
];
