var searchData=
[
  ['red',['RED',['../utilities_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'utilities.h']]],
  ['rows',['ROWS',['../utilities_8h.html#a3cfd3aa62338d12609f6d65bce97e9cd',1,'utilities.h']]]
];
