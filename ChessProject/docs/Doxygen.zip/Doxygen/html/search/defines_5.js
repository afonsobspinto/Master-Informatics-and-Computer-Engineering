var searchData=
[
  ['h_5fres',['H_RES',['../video__gr_8c.html#abf6f66114c31b8f87c80534ca695a00b',1,'video_gr.c']]]
];
