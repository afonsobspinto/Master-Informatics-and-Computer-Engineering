var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "_bdmpt",
  2: "bcgiklmrtuv",
  3: "bcdfgiklmnrtuvw",
  4: "bcdefghijlmnoprstvwxyz",
  5: "adgmw",
  6: "abcdefmnpstw",
  7: "bcdfghklmpqrstvwxy",
  8: "bilrtv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Modules"
};

