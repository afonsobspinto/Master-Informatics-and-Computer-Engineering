var searchData=
[
  ['wednesday',['WEDNESDAY',['../group__rtc.html#gga107600149f9b39f65d76e0e5ea2617d8a68288a23958cd9e1705fd81f0ee729c7',1,'rtc.h']]],
  ['white2play',['WHITE2PLAY',['../game_8h.html#a4cc39f049df62b331976f9a4482bd3eaab8b697e16d1ece0b8cdde2b2cc8a93d6',1,'game.h']]],
  ['whitedraw',['WHITEDRAW',['../game_8h.html#aa2099fd9fcf61fe76049a7383a4fb88fae5609263117a44a890bd4100484062f4',1,'game.h']]],
  ['whitewins',['WHITEWINS',['../game_8h.html#a4cc39f049df62b331976f9a4482bd3eaa2a6cb33638421ed32ed87945c4fe4ac3',1,'game.h']]]
];
