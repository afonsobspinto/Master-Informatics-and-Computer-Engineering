var searchData=
[
  ['bcd2binary',['bcd2binary',['../group__rtc.html#gad73913e9c11f3a52f505fbb7f3410646',1,'bcd2binary(unsigned long num):&#160;rtc.c'],['../group__rtc.html#gad73913e9c11f3a52f505fbb7f3410646',1,'bcd2binary(unsigned long num):&#160;rtc.c']]]
];
