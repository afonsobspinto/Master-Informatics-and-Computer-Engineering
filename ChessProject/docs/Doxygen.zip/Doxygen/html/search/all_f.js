var searchData=
[
  ['oemdata',['oemData',['../struct____attribute____.html#a7a78508038288b1ddb0e5c65aab0f3e6',1,'__attribute__']]],
  ['oemproductnameptr',['oemProductNamePtr',['../struct____attribute____.html#a0e327ae118cf12c8fe03ef66fddd7cc7',1,'__attribute__']]],
  ['oemproductrevptr',['oemProductRevPtr',['../struct____attribute____.html#a872943a323fcaa4d60de561c95c3a575',1,'__attribute__']]],
  ['oemsoftwarerev',['oemSoftwareRev',['../struct____attribute____.html#a9eab4c1a5fcfe86db4c1a0597747b51e',1,'__attribute__']]],
  ['oemstringptr',['oemStringPtr',['../struct____attribute____.html#a2befc429bd15e471103f859d993f4c9a',1,'__attribute__']]],
  ['oemvendornameptr',['oemVendorNamePtr',['../struct____attribute____.html#aa71a751b4a46beb84ecdf16262aeaedd',1,'__attribute__']]],
  ['offset',['offset',['../struct_bitmap_file_header.html#a29b5297d3393519050e3126c4cb07c1c',1,'BitmapFileHeader']]],
  ['one',['one',['../bitmap_8c.html#a80e7bcf01a03e735a1c2ac42a1edbdf5',1,'bitmap.c']]]
];
