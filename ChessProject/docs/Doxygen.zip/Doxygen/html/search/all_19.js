var searchData=
[
  ['y',['y',['../struct_mouse.html#a0a2f84ed7838f07779ae24c5a9086d33',1,'Mouse']]],
  ['y_5fdelta',['y_delta',['../structmouse__struct.html#ac378e5da3db43e2b77e867309cf0c447',1,'mouse_struct']]],
  ['y_5fovf',['y_ovf',['../structmouse__struct.html#a6da62ae366c2dc6a364a2613179269f4',1,'mouse_struct']]],
  ['y_5fsign',['y_sign',['../structmouse__struct.html#a15a549b266499b20a45e93ce9a91f083',1,'mouse_struct']]],
  ['ycharsize',['YCharSize',['../struct____attribute____.html#a330f00ebd49dccd2325d43cdbd646f09',1,'__attribute__']]],
  ['year',['year',['../group__rtc.html#ga3c8e0753ac2dd4b54f84cfb2b4663c08',1,'date_info_t']]],
  ['year_5faddr',['YEAR_ADDR',['../group__rtc.html#gac6365d7f429ac4e05ecb88880d32a551',1,'rtc.h']]],
  ['yellow',['YELLOW',['../utilities_8h.html#abf681265909adf3d3e8116c93c0ba179',1,'utilities.h']]],
  ['yexit',['YEXIT',['../utilities_8h.html#a0a8586c3a8f86c845078e8bcb560ec8a',1,'utilities.h']]],
  ['ylocal',['YLOCAL',['../utilities_8h.html#acd10a0032a89b7fad27988d250bfb48e',1,'utilities.h']]],
  ['ypos',['ypos',['../struct_piece.html#a4db09a4236b6f591c377857b932eb41a',1,'Piece']]],
  ['yresolution',['YResolution',['../struct____attribute____.html#afa8aba2156994750d500f85d0f8425cb',1,'__attribute__::YResolution()'],['../struct_bitmap_info_header.html#aa2f350dd0bda750656d5db5f5e37b2b3',1,'BitmapInfoHeader::yResolution()']]],
  ['yserial',['YSERIAL',['../utilities_8h.html#a32707269f0046264ec3a91abd1c0a62b',1,'utilities.h']]]
];
