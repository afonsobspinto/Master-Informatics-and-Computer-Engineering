var searchData=
[
  ['kbc_5fread',['kbc_read',['../kbd_8c.html#adaed5b36eb97464c884829177ae23d04',1,'kbc_read(unsigned char *st):&#160;kbd.c'],['../kbd_8h.html#adaed5b36eb97464c884829177ae23d04',1,'kbc_read(unsigned char *st):&#160;kbd.c']]],
  ['kbc_5fread_5fstatus',['kbc_read_status',['../kbd_8c.html#a21673d0c3ff0872e1671314744e3e123',1,'kbc_read_status(unsigned long *status):&#160;kbd.c'],['../kbd_8h.html#a21673d0c3ff0872e1671314744e3e123',1,'kbc_read_status(unsigned long *status):&#160;kbd.c']]],
  ['kbc_5fsend_5fdata',['kbc_send_data',['../kbd_8c.html#acc5fbf6dec8d1b6865d2878243bf3456',1,'kbc_send_data(unsigned char cmd):&#160;kbd.c'],['../kbd_8h.html#acc5fbf6dec8d1b6865d2878243bf3456',1,'kbc_send_data(unsigned char cmd):&#160;kbd.c']]],
  ['kbc_5fsubscribe_5fint',['kbc_subscribe_int',['../kbd_8c.html#a145e5f5135c8440e6ed6f4a8d6bad21d',1,'kbc_subscribe_int(unsigned *kbc_hook):&#160;kbd.c'],['../kbd_8h.html#a09a6ccb967ae0414c995d79a3b1fb5cd',1,'kbc_subscribe_int(unsigned *kbd_hook):&#160;kbd.c']]],
  ['kbc_5funsubscribe_5fint',['kbc_unsubscribe_int',['../kbd_8c.html#a40bd7c145ca167ffbe33448711f06c82',1,'kbc_unsubscribe_int(unsigned hook_id):&#160;kbd.c'],['../kbd_8h.html#a40bd7c145ca167ffbe33448711f06c82',1,'kbc_unsubscribe_int(unsigned hook_id):&#160;kbd.c']]],
  ['kbc_5fwrite_5fto_5fmouse',['kbc_write_to_mouse',['../kbd_8c.html#a5231f84888974f804717711bdb38bfea',1,'kbc_write_to_mouse():&#160;kbd.c'],['../kbd_8h.html#a5231f84888974f804717711bdb38bfea',1,'kbc_write_to_mouse():&#160;kbd.c']]],
  ['kbd_5fsubscribe_5fint',['kbd_subscribe_int',['../group__timer.html#ga77bdb04aa2801242afbe0b3f01fcb3e4',1,'timer.h']]],
  ['kbd_5funsubscribe_5fint',['kbd_unsubscribe_int',['../group__timer.html#ga40cf2b25cfb87ee212ebaefc1e8f4353',1,'timer.h']]]
];
