var searchData=
[
  ['game_5fmanagement',['game_management',['../game_8c.html#a8d9ebd35e420c58d6d601df99a304e6c',1,'game_management():&#160;game.c'],['../game_8h.html#a8d9ebd35e420c58d6d601df99a304e6c',1,'game_management():&#160;game.c']]],
  ['getdrawstate',['getDrawState',['../game_8h.html#a85b3c766cbf20a3cd4f80b072058812c',1,'game.h']]],
  ['getgamestate',['getGameState',['../game_8c.html#a183c37852fcdca8723613a9034f5e2d6',1,'getGameState():&#160;game.c'],['../game_8h.html#a183c37852fcdca8723613a9034f5e2d6',1,'getGameState():&#160;game.c']]],
  ['getgraphicsbuffer',['getGraphicsBuffer',['../group__video__gr.html#ga0823d182cf2b320e5f344bdc420a02d0',1,'video_gr.h']]],
  ['gethorresolution',['getHorResolution',['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c'],['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c']]],
  ['getmatrixat',['getMatrixAt',['../chess_8c.html#a58e023ce36de89fb97884e6d3299d7f5',1,'getMatrixAt(int x, int y):&#160;chess.c'],['../chess_8h.html#a58e023ce36de89fb97884e6d3299d7f5',1,'getMatrixAt(int x, int y):&#160;chess.c']]],
  ['getmenustate',['getMenuState',['../_chess_project_8c.html#a9b1e0dfc9b5ae05928f7a3e974d3fc17',1,'getMenuState():&#160;ChessProject.c'],['../_chess_project_8h.html#a9b1e0dfc9b5ae05928f7a3e974d3fc17',1,'getMenuState():&#160;ChessProject.c']]],
  ['getmouse',['getMouse',['../mouse_8c.html#a8d3f3987b96a716cc9c3aa8e484ff1d7',1,'getMouse():&#160;mouse.c'],['../mouse_8h.html#a8d3f3987b96a716cc9c3aa8e484ff1d7',1,'getMouse():&#160;mouse.c']]],
  ['getmovestate',['getMoveState',['../game_8c.html#ac56c084a5fdb027e060795d60d2799dd',1,'getMoveState():&#160;game.c'],['../game_8h.html#ac56c084a5fdb027e060795d60d2799dd',1,'getMoveState():&#160;game.c']]],
  ['getverresolution',['getVerResolution',['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c'],['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c']]]
];
