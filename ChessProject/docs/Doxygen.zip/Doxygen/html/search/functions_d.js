var searchData=
[
  ['vbe_5fget_5fcontroler_5finfo',['vbe_get_controler_info',['../group__vbe.html#ga78e9bcd24c950025414a4d072414970b',1,'vbe_get_controler_info(vbe_info_t *vbe_ptr):&#160;vbe.c'],['../group__vbe.html#ga78e9bcd24c950025414a4d072414970b',1,'vbe_get_controler_info(vbe_info_t *vbe_ptr):&#160;vbe.c']]],
  ['vbe_5fget_5fmode_5finfo',['vbe_get_mode_info',['../group__vbe.html#ga8218d77e782bd25ec027c3ccb8dc2d51',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_ptr):&#160;vbe.c'],['../group__vbe.html#ga8218d77e782bd25ec027c3ccb8dc2d51',1,'vbe_get_mode_info(unsigned short mode, vbe_mode_info_t *vmi_ptr):&#160;vbe.c']]],
  ['vg_5fexit',['vg_exit',['../group__video__gr.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit():&#160;video_gr.c'],['../group__video__gr.html#ga42f593e6656f1a978315aff02b1bcebf',1,'vg_exit(void):&#160;video_gr.c']]],
  ['vg_5finit',['vg_init',['../group__video__gr.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c'],['../group__video__gr.html#gacef21667c79365d57a084bed994c2189',1,'vg_init(unsigned short mode):&#160;video_gr.c']]]
];
