var searchData=
[
  ['quitx',['QUITX',['../utilities_8h.html#ae6b1ee9bb4455757f8cefd7607b1be7a',1,'utilities.h']]]
];
