var searchData=
[
  ['black2play',['BLACK2PLAY',['../game_8h.html#a4cc39f049df62b331976f9a4482bd3eaaf94cba35a1ad10da80d75432adec63ed',1,'game.h']]],
  ['blackdraw',['BLACKDRAW',['../game_8h.html#aa2099fd9fcf61fe76049a7383a4fb88faf14ce05e4a892365beb9bcf9cfbe61b9',1,'game.h']]],
  ['blackwins',['BLACKWINS',['../game_8h.html#a4cc39f049df62b331976f9a4482bd3eaa429df672e339e19397b7246d32db54f7',1,'game.h']]]
];
