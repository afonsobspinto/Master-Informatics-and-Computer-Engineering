var searchData=
[
  ['reset',['reset',['../game_8c.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;game.c'],['../game_8h.html#ad20897c5c8bd47f5d4005989bead0e55',1,'reset():&#160;game.c']]],
  ['reset_5fdraw',['reset_draw',['../mouse_8h.html#a19d81ee579b780a59d2ab1f6c6d5c877',1,'mouse.h']]],
  ['reset_5fflags',['reset_flags',['../chess_8c.html#a87b65875fe41cfd8b001e876b80d6a45',1,'reset_flags():&#160;chess.c'],['../chess_8h.html#a87b65875fe41cfd8b001e876b80d6a45',1,'reset_flags():&#160;chess.c']]],
  ['rtc_5fdisable',['rtc_disable',['../group__rtc.html#gaeb55d907395f650cc700c948cfc6eadb',1,'rtc_disable():&#160;rtc.c'],['../group__rtc.html#gaeb55d907395f650cc700c948cfc6eadb',1,'rtc_disable():&#160;rtc.c']]],
  ['rtc_5fenable',['rtc_enable',['../group__rtc.html#gac9d2c3fa04a4b1bc66a5175136feb12f',1,'rtc_enable():&#160;rtc.c'],['../group__rtc.html#gac9d2c3fa04a4b1bc66a5175136feb12f',1,'rtc_enable():&#160;rtc.c']]],
  ['rtc_5fget_5fdate',['rtc_get_date',['../group__rtc.html#ga8fae7c0e1767f0ac8b9921be3fa1285b',1,'rtc_get_date(date_info_t *date):&#160;rtc.c'],['../group__rtc.html#ga8fae7c0e1767f0ac8b9921be3fa1285b',1,'rtc_get_date(date_info_t *date):&#160;rtc.c']]],
  ['rtc_5fget_5ftime',['rtc_get_time',['../group__rtc.html#ga8c860595cf8aa0e139fc974810630094',1,'rtc_get_time(time_info_t *time):&#160;rtc.c'],['../group__rtc.html#ga8c860595cf8aa0e139fc974810630094',1,'rtc_get_time(time_info_t *time):&#160;rtc.c']]]
];
