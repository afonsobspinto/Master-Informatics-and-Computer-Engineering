var searchData=
[
  ['gametime',['gameTime',['../game_8c.html#a3ebcdf8ce181be8868eae672d0e0ac6b',1,'game.c']]],
  ['gap',['GAP',['../utilities_8h.html#a2a2129b3f6b7ce06869b7f16b81aff6f',1,'utilities.h']]]
];
