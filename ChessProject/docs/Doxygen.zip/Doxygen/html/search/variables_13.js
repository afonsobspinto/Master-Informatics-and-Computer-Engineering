var searchData=
[
  ['x',['x',['../struct_mouse.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Mouse']]],
  ['x_5fdelta',['x_delta',['../structmouse__struct.html#a5d735e452e8bd371ad1a61a524e7cecb',1,'mouse_struct']]],
  ['x_5fovf',['x_ovf',['../structmouse__struct.html#a6eff97cd85d3d2081ca37c96fc71564f',1,'mouse_struct']]],
  ['x_5fsign',['x_sign',['../structmouse__struct.html#afafa8b75fed0e0ab9ff250e558be627b',1,'mouse_struct']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#a047d8f41434f02589d0c9b90b17c67eb',1,'__attribute__']]],
  ['xpos',['xpos',['../struct_piece.html#a4c8fb3f1c1ae597ee856290390ebc274',1,'Piece']]],
  ['xresolution',['xResolution',['../struct_bitmap_info_header.html#ac6eaeb4c0876cf6cd899f41fe3c25ff5',1,'BitmapInfoHeader::xResolution()'],['../struct____attribute____.html#a16f6408e5a85c7a7785a0cee64b6a219',1,'__attribute__::XResolution()']]]
];
