var searchData=
[
  ['saturday',['SATURDAY',['../group__rtc.html#gga107600149f9b39f65d76e0e5ea2617d8a31bbcd6fa6a28095ef8de658126aa5ec',1,'rtc.h']]],
  ['sunday',['SUNDAY',['../group__rtc.html#gga107600149f9b39f65d76e0e5ea2617d8ad86a75e0b97510de54435996ae45b8d2',1,'rtc.h']]]
];
