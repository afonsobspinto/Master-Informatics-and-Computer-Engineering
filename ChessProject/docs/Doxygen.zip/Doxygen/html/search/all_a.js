var searchData=
[
  ['j',['j',['../struct_piece.html#a37d972ae0b47b9099e30983131d31916',1,'Piece']]]
];
