var searchData=
[
  ['increment',['increment',['../game_8c.html#ae00a38cbcd38e49e952de3fd80fcc6e7',1,'increment(int *counter):&#160;game.c'],['../game_8h.html#ae00a38cbcd38e49e952de3fd80fcc6e7',1,'increment(int *counter):&#160;game.c']]],
  ['isbuttonselected',['isButtonSelected',['../mouse_8h.html#aa6389bb18ccd2329477c810e4b876fe6',1,'mouse.h']]],
  ['ischeck',['isCheck',['../chess_8c.html#aba78015d9854506ebc42283b3e165ebc',1,'isCheck(unsigned char color):&#160;chess.c'],['../chess_8h.html#aba78015d9854506ebc42283b3e165ebc',1,'isCheck(unsigned char color):&#160;chess.c']]],
  ['ismate',['isMate',['../chess_8c.html#ae0fd179f6dfdba9bdc0e9a8a2e525af7',1,'isMate(unsigned char color):&#160;chess.c'],['../chess_8h.html#ae0fd179f6dfdba9bdc0e9a8a2e525af7',1,'isMate(unsigned char color):&#160;chess.c']]],
  ['ispar',['isPar',['../chess_8c.html#a6f1387d264278e038a7e894dea7b5ff9',1,'isPar(int x):&#160;chess.c'],['../chess_8h.html#a6f1387d264278e038a7e894dea7b5ff9',1,'isPar(int x):&#160;chess.c']]],
  ['ispieceselected',['isPieceSelected',['../mouse_8c.html#ae2710d8b3e8f299c05e7cdfb1032e883',1,'isPieceSelected(int flag):&#160;mouse.c'],['../mouse_8h.html#ae2710d8b3e8f299c05e7cdfb1032e883',1,'isPieceSelected(int flag):&#160;mouse.c']]],
  ['isvalidmove',['isValidMove',['../chess_8c.html#a73f0d7077a5ae1cba139951bc69586ce',1,'isValidMove(Piece p1, Piece p2, int checking):&#160;chess.c'],['../chess_8h.html#a73f0d7077a5ae1cba139951bc69586ce',1,'isValidMove(Piece p1, Piece p2, int checking):&#160;chess.c']]]
];
