var searchData=
[
  ['w_5fen_5fpassant',['W_EN_PASSANT',['../chess_8h.html#a59c7c39195a624a143208d2aec095f6f',1,'chess.h']]],
  ['white',['WHITE',['../utilities_8h.html#a87b537f5fa5c109d3c05c13d6b18f382',1,'utilities.h']]],
  ['white_5flong_5fcastling',['WHITE_LONG_CASTLING',['../chess_8h.html#ab107d84804e224fd71887fe96ca26ca4',1,'chess.h']]],
  ['white_5fshort_5fcastling',['WHITE_SHORT_CASTLING',['../chess_8h.html#a4a71409db77e0a8c3c8d3ec262b2fb7b',1,'chess.h']]],
  ['widthexit',['WIDTHEXIT',['../utilities_8h.html#ab3a2e77072f4ced7234aab39bcbde19d',1,'utilities.h']]],
  ['widthlocal',['WIDTHLOCAL',['../utilities_8h.html#a3c82c002eec3096a079747e2f16fffa7',1,'utilities.h']]],
  ['widthserial',['WIDTHSERIAL',['../utilities_8h.html#a0a657dc9957a79e883094caefeccaa26',1,'utilities.h']]]
];
