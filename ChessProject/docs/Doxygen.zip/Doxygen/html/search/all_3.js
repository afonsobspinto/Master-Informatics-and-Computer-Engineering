var searchData=
[
  ['call_5fdrawbitmap',['call_drawBitmap',['../group__video__gr.html#ga47999dfb1d33526145ffba60d768df3a',1,'call_drawBitmap(Bitmap *bmp, int x, int y, Alignment alignment):&#160;video_gr.c'],['../group__video__gr.html#ga47999dfb1d33526145ffba60d768df3a',1,'call_drawBitmap(Bitmap *bmp, int x, int y, Alignment alignment):&#160;video_gr.c']]],
  ['capabilities',['capabilities',['../struct____attribute____.html#ae9ca34c5596252bd697ac999fb008dfa',1,'__attribute__']]],
  ['castling',['CASTLING',['../game_8h.html#a6c9dae021f3e00171665c96e60922570a5755f8a7b585a843fc3911779355f97e',1,'game.h']]],
  ['checkmate',['CHECKMATE',['../chess_8h.html#abec42f1abae3c920d7804783ac4e8eef',1,'chess.h']]],
  ['chess_2ec',['chess.c',['../chess_8c.html',1,'']]],
  ['chess_2eh',['chess.h',['../chess_8h.html',1,'']]],
  ['chessproject_2ec',['ChessProject.c',['../_chess_project_8c.html',1,'']]],
  ['chessproject_2eh',['ChessProject.h',['../_chess_project_8h.html',1,'']]],
  ['chessproject_5fexit',['chessproject_exit',['../_chess_project_8c.html#a1b9fcaee0546635e48d2f03bbc5d869c',1,'chessproject_exit():&#160;ChessProject.c'],['../_chess_project_8h.html#a1b9fcaee0546635e48d2f03bbc5d869c',1,'chessproject_exit():&#160;ChessProject.c']]],
  ['chessproject_5fstart',['chessproject_start',['../_chess_project_8c.html#a47b8ac18c1a27fa74fa5f5d6a420cc29',1,'chessproject_start():&#160;ChessProject.c'],['../_chess_project_8h.html#a47b8ac18c1a27fa74fa5f5d6a420cc29',1,'chessproject_start():&#160;ChessProject.c']]],
  ['colon',['colon',['../bitmap_8c.html#ad2b73cfa3250a1cf2cf044660c51daaa',1,'bitmap.c']]],
  ['color',['color',['../struct_piece.html#ae2d77c102b2d2d3f0881c0e2bcdbe777',1,'Piece::color()'],['../struct_mouse.html#a0fd02fb9277ffcb35a75066ffe95e8c7',1,'Mouse::color()']]],
  ['cols',['COLS',['../utilities_8h.html#ab59ad2ee1a48b83c2eef1f019ed8cc48',1,'utilities.h']]],
  ['compression',['compression',['../struct_bitmap_info_header.html#ad180079f62b44e49ec672c9ef6e078b3',1,'BitmapInfoHeader']]],
  ['copy2mbuffer',['copy2Mbuffer',['../group__video__gr.html#gad7ed5126596fa9a7253f588cdb167ae5',1,'copy2Mbuffer():&#160;video_gr.c'],['../group__video__gr.html#gad7ed5126596fa9a7253f588cdb167ae5',1,'copy2Mbuffer():&#160;video_gr.c']]],
  ['copy2videomem',['copy2VideoMem',['../group__video__gr.html#ga1425a5c9a2847f8ca8ad81792cea8bd5',1,'copy2VideoMem():&#160;video_gr.c'],['../group__video__gr.html#ga1425a5c9a2847f8ca8ad81792cea8bd5',1,'copy2VideoMem():&#160;video_gr.c']]],
  ['copy2videomem3',['copy2VideoMem3',['../group__video__gr.html#ga4871ac3a67bd8baae20ef4740880cc2e',1,'copy2VideoMem3():&#160;video_gr.c'],['../group__video__gr.html#ga4871ac3a67bd8baae20ef4740880cc2e',1,'copy2VideoMem3():&#160;video_gr.c']]],
  ['correction',['CORRECTION',['../utilities_8h.html#a6b2cea537eda125cb3b39529ca4696f7',1,'utilities.h']]],
  ['counterplayer1',['counterPlayer1',['../game_8c.html#a8a8390b7b36a30ae0206e7150ca32e0f',1,'game.c']]],
  ['counterplayer2',['counterPlayer2',['../game_8c.html#a08e76a5311418fc4c78bd1b3806ce160',1,'game.c']]]
];
