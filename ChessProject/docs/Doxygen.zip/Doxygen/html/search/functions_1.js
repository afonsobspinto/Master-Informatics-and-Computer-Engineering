var searchData=
[
  ['call_5fdrawbitmap',['call_drawBitmap',['../group__video__gr.html#ga47999dfb1d33526145ffba60d768df3a',1,'call_drawBitmap(Bitmap *bmp, int x, int y, Alignment alignment):&#160;video_gr.c'],['../group__video__gr.html#ga47999dfb1d33526145ffba60d768df3a',1,'call_drawBitmap(Bitmap *bmp, int x, int y, Alignment alignment):&#160;video_gr.c']]],
  ['chessproject_5fexit',['chessproject_exit',['../_chess_project_8c.html#a1b9fcaee0546635e48d2f03bbc5d869c',1,'chessproject_exit():&#160;ChessProject.c'],['../_chess_project_8h.html#a1b9fcaee0546635e48d2f03bbc5d869c',1,'chessproject_exit():&#160;ChessProject.c']]],
  ['chessproject_5fstart',['chessproject_start',['../_chess_project_8c.html#a47b8ac18c1a27fa74fa5f5d6a420cc29',1,'chessproject_start():&#160;ChessProject.c'],['../_chess_project_8h.html#a47b8ac18c1a27fa74fa5f5d6a420cc29',1,'chessproject_start():&#160;ChessProject.c']]],
  ['copy2mbuffer',['copy2Mbuffer',['../group__video__gr.html#gad7ed5126596fa9a7253f588cdb167ae5',1,'copy2Mbuffer():&#160;video_gr.c'],['../group__video__gr.html#gad7ed5126596fa9a7253f588cdb167ae5',1,'copy2Mbuffer():&#160;video_gr.c']]],
  ['copy2videomem',['copy2VideoMem',['../group__video__gr.html#ga1425a5c9a2847f8ca8ad81792cea8bd5',1,'copy2VideoMem():&#160;video_gr.c'],['../group__video__gr.html#ga1425a5c9a2847f8ca8ad81792cea8bd5',1,'copy2VideoMem():&#160;video_gr.c']]],
  ['copy2videomem3',['copy2VideoMem3',['../group__video__gr.html#ga4871ac3a67bd8baae20ef4740880cc2e',1,'copy2VideoMem3():&#160;video_gr.c'],['../group__video__gr.html#ga4871ac3a67bd8baae20ef4740880cc2e',1,'copy2VideoMem3():&#160;video_gr.c']]]
];
