var searchData=
[
  ['game_2ec',['game.c',['../game_8c.html',1,'']]],
  ['game_2ed',['game.d',['../game_8d.html',1,'']]],
  ['game_2eh',['game.h',['../game_8h.html',1,'']]],
  ['game_5fmanagement',['game_management',['../game_8c.html#a8d9ebd35e420c58d6d601df99a304e6c',1,'game_management():&#160;game.c'],['../game_8h.html#a8d9ebd35e420c58d6d601df99a304e6c',1,'game_management():&#160;game.c']]],
  ['game_5fstate',['game_state',['../game_8c.html#ae7c9d8f9188a763563ea9f712b848489',1,'game_state():&#160;game.c'],['../game_8h.html#a4cc39f049df62b331976f9a4482bd3ea',1,'GAME_STATE():&#160;game.h']]],
  ['gametime',['gameTime',['../game_8c.html#a3ebcdf8ce181be8868eae672d0e0ac6b',1,'game.c']]],
  ['gap',['GAP',['../utilities_8h.html#a2a2129b3f6b7ce06869b7f16b81aff6f',1,'utilities.h']]],
  ['getdrawstate',['getDrawState',['../game_8h.html#a85b3c766cbf20a3cd4f80b072058812c',1,'game.h']]],
  ['getgamestate',['getGameState',['../game_8c.html#a183c37852fcdca8723613a9034f5e2d6',1,'getGameState():&#160;game.c'],['../game_8h.html#a183c37852fcdca8723613a9034f5e2d6',1,'getGameState():&#160;game.c']]],
  ['getgraphicsbuffer',['getGraphicsBuffer',['../group__video__gr.html#ga0823d182cf2b320e5f344bdc420a02d0',1,'video_gr.h']]],
  ['gethorresolution',['getHorResolution',['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c'],['../group__video__gr.html#gae2b9b38f4f97e1c580123c8e9a993353',1,'getHorResolution():&#160;video_gr.c']]],
  ['getmatrixat',['getMatrixAt',['../chess_8c.html#a58e023ce36de89fb97884e6d3299d7f5',1,'getMatrixAt(int x, int y):&#160;chess.c'],['../chess_8h.html#a58e023ce36de89fb97884e6d3299d7f5',1,'getMatrixAt(int x, int y):&#160;chess.c']]],
  ['getmenustate',['getMenuState',['../_chess_project_8c.html#a9b1e0dfc9b5ae05928f7a3e974d3fc17',1,'getMenuState():&#160;ChessProject.c'],['../_chess_project_8h.html#a9b1e0dfc9b5ae05928f7a3e974d3fc17',1,'getMenuState():&#160;ChessProject.c']]],
  ['getmouse',['getMouse',['../mouse_8c.html#a8d3f3987b96a716cc9c3aa8e484ff1d7',1,'getMouse():&#160;mouse.c'],['../mouse_8h.html#a8d3f3987b96a716cc9c3aa8e484ff1d7',1,'getMouse():&#160;mouse.c']]],
  ['getmovestate',['getMoveState',['../game_8c.html#ac56c084a5fdb027e060795d60d2799dd',1,'getMoveState():&#160;game.c'],['../game_8h.html#ac56c084a5fdb027e060795d60d2799dd',1,'getMoveState():&#160;game.c']]],
  ['getverresolution',['getVerResolution',['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c'],['../group__video__gr.html#ga7ee85b0f333d227380a2c43e5fb8507a',1,'getVerResolution():&#160;video_gr.c']]],
  ['greenfieldposition',['GreenFieldPosition',['../struct____attribute____.html#a602b28f8e5da781eabfd736743a6ea09',1,'__attribute__']]],
  ['greenmasksize',['GreenMaskSize',['../struct____attribute____.html#ac7b4df72e505b74493e7d5144cbac743',1,'__attribute__']]]
];
