var searchData=
[
  ['castling',['CASTLING',['../game_8h.html#a6c9dae021f3e00171665c96e60922570a5755f8a7b585a843fc3911779355f97e',1,'game.h']]]
];
