var searchData=
[
  ['time_5fmanagement',['time_management',['../group__timer.html#gac9d278b6fdb94ad7a0db4d47afc1461e',1,'timer.h']]],
  ['timer_5fsubscribe_5fint',['timer_subscribe_int',['../group__timer.html#ga4c5d9f47323eda494cfd826f6d62eec9',1,'timer_subscribe_int(void):&#160;timer.c'],['../group__timer.html#ga4c5d9f47323eda494cfd826f6d62eec9',1,'timer_subscribe_int(void):&#160;timer.c']]],
  ['timer_5funsubscribe_5fint',['timer_unsubscribe_int',['../group__timer.html#gab9eea51549744bca5c5c923b388bb4ee',1,'timer_unsubscribe_int():&#160;timer.c'],['../group__timer.html#gab9eea51549744bca5c5c923b388bb4ee',1,'timer_unsubscribe_int():&#160;timer.c']]],
  ['turngamestate',['turnGameState',['../game_8c.html#a9a8b29c80ca59b3c9fb34e53700021c5',1,'turnGameState():&#160;game.c'],['../game_8h.html#a9a8b29c80ca59b3c9fb34e53700021c5',1,'turnGameState():&#160;game.c']]]
];
