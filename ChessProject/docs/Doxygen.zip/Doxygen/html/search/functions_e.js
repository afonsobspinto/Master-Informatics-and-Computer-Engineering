var searchData=
[
  ['wait_5fvalid_5frtc',['wait_valid_rtc',['../group__rtc.html#ga788e56085fe57e083210ad3c8887ecb1',1,'wait_valid_rtc(void):&#160;rtc.c'],['../group__rtc.html#ga788e56085fe57e083210ad3c8887ecb1',1,'wait_valid_rtc(void):&#160;rtc.c']]],
  ['waitforenter',['waitForEnter',['../game_8c.html#ad9f9670d060301869165ab2f90549835',1,'waitForEnter():&#160;game.c'],['../game_8h.html#ad9f9670d060301869165ab2f90549835',1,'waitForEnter():&#160;game.c']]],
  ['winnerstate',['winnerState',['../game_8c.html#a0a40508e98b3f0ad7f132c0433cee799',1,'winnerState():&#160;game.c'],['../game_8h.html#a0a40508e98b3f0ad7f132c0433cee799',1,'winnerState():&#160;game.c']]]
];
