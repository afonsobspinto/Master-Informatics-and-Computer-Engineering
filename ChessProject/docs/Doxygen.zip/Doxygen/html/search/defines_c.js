var searchData=
[
  ['second_5fbuffer',['SECOND_BUFFER',['../utilities_8h.html#a61d8e9604f394a9aafac4d7b3d9b4dfb',1,'utilities.h']]],
  ['set_5freset_5fcmd',['SET_RESET_CMD',['../macros_8h.html#a3f5f6b73cf7cd6a4fdd7fa226723fdd2',1,'macros.h']]],
  ['set_5fvbe_5fmode',['SET_VBE_MODE',['../macros_8h.html#ab32156e1d72cb92b120bb16883c87eea',1,'macros.h']]],
  ['square_5fsize',['SQUARE_SIZE',['../utilities_8h.html#aa465c0206c08c9cde6075c2afb1c8bc8',1,'utilities.h']]],
  ['stalemate',['STALEMATE',['../chess_8h.html#ac353023586fc17116e7301b372f3c480',1,'chess.h']]]
];
