var searchData=
[
  ['capabilities',['capabilities',['../struct____attribute____.html#ae9ca34c5596252bd697ac999fb008dfa',1,'__attribute__']]],
  ['colon',['colon',['../bitmap_8c.html#ad2b73cfa3250a1cf2cf044660c51daaa',1,'bitmap.c']]],
  ['color',['color',['../struct_piece.html#ae2d77c102b2d2d3f0881c0e2bcdbe777',1,'Piece::color()'],['../struct_mouse.html#a0fd02fb9277ffcb35a75066ffe95e8c7',1,'Mouse::color()']]],
  ['compression',['compression',['../struct_bitmap_info_header.html#ad180079f62b44e49ec672c9ef6e078b3',1,'BitmapInfoHeader']]],
  ['counterplayer1',['counterPlayer1',['../game_8c.html#a8a8390b7b36a30ae0206e7150ca32e0f',1,'game.c']]],
  ['counterplayer2',['counterPlayer2',['../game_8c.html#a08e76a5311418fc4c78bd1b3806ce160',1,'game.c']]]
];
